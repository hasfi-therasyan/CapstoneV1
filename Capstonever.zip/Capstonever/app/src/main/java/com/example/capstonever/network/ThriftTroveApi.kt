package com.example.capstonever.network

import com.example.capstonever.network.AddItemResponse
import com.example.capstonever.network.AddToCartRequest
import com.example.capstonever.network.AddToCartResponse
import com.example.capstonever.network.CartItem
import com.example.capstonever.network.CheckoutRequest
import com.example.capstonever.network.CheckoutResponse
import com.example.capstonever.network.DeleteCartRequest
import com.example.capstonever.network.DeleteCartResponse
import com.example.capstonever.network.DeleteItemResponse
import com.example.capstonever.network.Item
import com.example.capstonever.network.LoginRequest
import com.example.capstonever.network.LoginResponse
import com.example.capstonever.network.SignUpRequest
import com.example.capstonever.network.SignUpResponse
import com.example.capstonever.network.TrackOrderResponse
import com.example.capstonever.network.UpdateCartRequest
import com.example.capstonever.network.UpdateCartResponse
import com.example.capstonever.network.UpdateItemResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*

interface ThriftTroveApi {
    @POST("/signup")
    suspend fun signUp(@Body request: SignUpRequest): SignUpResponse

    @POST("/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @GET("/items")
    suspend fun getItems(): List<Item>

    @GET("/items/{id}")
    suspend fun getItemById(@Path("id") id: String): Item

    @POST("/items")
    suspend fun addItem(
        @Header("Authorization") token: String,
        @Part image: MultipartBody.Part,
        @Part("name") name: RequestBody,
        @Part("description") description: RequestBody,
        @Part("price") price: RequestBody
    ): AddItemResponse

    @POST("/cart")
    suspend fun addItemToCart(@Header("Authorization") token: String, @Body request: AddToCartRequest): AddToCartResponse

    @PUT("/items/{id}")
    suspend fun updateItem(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Part image: MultipartBody.Part?,
        @Part("name") name: RequestBody,
        @Part("description") description: RequestBody,
        @Part("price") price: RequestBody
    ): UpdateItemResponse

    @DELETE("/items/{id}")
    suspend fun deleteItem(@Header("Authorization") token: String, @Path("id") id: String): DeleteItemResponse

    @GET("/itemsown")
    suspend fun getItemsByOwnerId(@Header("Authorization") token: String): List<Item>

    @POST("/checkout")
    suspend fun checkout(@Header("Authorization") token: String, @Body request: CheckoutRequest): CheckoutResponse

    @PUT("/cart")
    suspend fun updateCartItem(@Header("Authorization") token: String, @Body request: UpdateCartRequest): UpdateCartResponse

    @GET("/cart")
    suspend fun getCart(@Header("Authorization") token: String): List<CartItem>

    @DELETE("/cart")
    suspend fun deleteCartItem(@Header("Authorization") token: String, @Body request: DeleteCartRequest): DeleteCartResponse

    @GET("/track/{orderId}")
    suspend fun trackOrder(@Header("Authorization") token: String, @Path("orderId") orderId: String): TrackOrderResponse
}

package com.example.capstonever.signup

import androidx.lifecycle.ViewModel
import com.example.storyappdicoding.story.StoryRepository

class SignUpViewModel(private val storyRepository: StoryRepository) : ViewModel() {

    fun signUp(name: String, email: String, password: String) =
        storyRepository.postSignUp(name, email, password)
}

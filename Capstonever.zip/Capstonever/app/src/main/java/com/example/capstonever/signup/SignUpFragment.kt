package com.example.capstonever.signup

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.storyappdicoding.R
import com.example.storyappdicoding.data.Result
import com.example.storyappdicoding.databinding.FragmentSignUpBinding
import com.example.storyappdicoding.utils.ViewModelFactory

class SignUpFragment : Fragment() {

    private var binding: FragmentSignUpBinding? = null
    private val viewModel: SignUpViewModel by viewModels { ViewModelFactory(requireContext()) }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentSignUpBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
    }

    private fun setupUI() {
        binding?.apply {
            setupSignUpButton()
            setupHaveAccountTextView()
        }
    }

    private fun setupSignUpButton() {
        binding?.btSignUp?.setOnClickListener { view ->
            hideKeyboard(view)
            val name = binding?.edRegisterName?.text.toString()
            val email = binding?.edRegisterEmail?.text.toString()
            val password = binding?.edRegisterPassword?.text.toString()
            performSignUp(name, email, password)
        }
    }

    private fun setupHaveAccountTextView() {
        binding?.tvSignupHaveAccount?.setOnClickListener {
            findNavController().navigate(R.id.loginFragment)
        }
    }

    private fun performSignUp(name: String, email: String, password: String) {
        viewModel.signUp(name, email, password).observe(viewLifecycleOwner) { result -> handleSignUpResult(result) }
    }

    private fun handleSignUpResult(result: Result<SignUpResponse>?) {
        result?.let {
            when (it) {
                is Result.Loading -> showLoading(true)
                is Result.Success -> {
                    showLoading(false)
                    processSignUp(it.data)
                }
                is Result.Error -> {
                    showLoading(false)
                    showToast(it.error)
                }
            }
        }
    }

    private fun hideKeyboard(view: View) {
        val imm = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun processSignUp(data: SignUpResponse) {
        val message = if (data.error) "Failed in Signing Up" else "Please Proceed With Logging In"
        showToast(message)
        if (!data.error) {
            navigateToLoginFragment()
        }
    }

    private fun navigateToLoginFragment() {
        val action = SignUpFragmentDirections.actionSignUpFragmentToLoginFragment(isFromSignUp = true)
        findNavController().navigate(action)
    }

    private fun showLoading(state: Boolean) {
        binding?.apply {
            pbCreateSignup.isVisible = state
            edRegisterEmail.isInvisible = state
            edRegisterName.isInvisible = state
            edRegisterPassword.isInvisible = state
            textView2.isInvisible = state
            tvSignupHaveAccount.isInvisible = state
            btSignUp.isInvisible = state
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
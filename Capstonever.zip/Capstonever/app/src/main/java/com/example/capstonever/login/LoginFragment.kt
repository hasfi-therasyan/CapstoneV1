package com.example.capstonever.login

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.example.storyappdicoding.R
import com.example.storyappdicoding.data.Result
import com.example.storyappdicoding.databinding.FragmentLoginBinding
import com.example.storyappdicoding.utils.Preference
import com.example.storyappdicoding.utils.ViewModelFactory

class LoginFragment : Fragment() {

    private val binding get() = _binding!!
    private var _binding: FragmentLoginBinding? = null
    private val loginViewModel: LoginViewModel by viewModels { ViewModelFactory(requireContext()) }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.setupUI()
        binding.checkIfFromSignUp()
    }

    private fun FragmentLoginBinding.setupUI() {
        tvLoginDontHaveAccount.setOnClickListener(Navigation.createNavigateOnClickListener(R.id.signUpFragment))
        btLogin.setOnClickListener { performLogin() }
    }

    private fun FragmentLoginBinding.checkIfFromSignUp() {
        val isFromSignUp = arguments?.getBoolean("is_from_sign_up") ?: false
        if (isFromSignUp) handleBackPressed()
    }

    private fun performLogin() {
        val email = binding.edLoginEmail.text.toString()
        val password = binding.edLoginPassword.text.toString()
        hideKeyboard()
        loginViewModel.login(email, password).observe(viewLifecycleOwner, ::handleLoginResult)
    }

    private fun handleLoginResult(result: Result<LoginResponse>?) {
        result?.let {
            binding.setLoadingState(it is Result.Loading)
            when (it) {
                is Result.Success -> processLogin(it.data)
                is Result.Error -> showToast(it.error)
                else -> {}
            }
        }
    }

    private fun hideKeyboard() {
        val imm = requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view?.windowToken, 0)
    }

    private fun processLogin(data: LoginResponse) {
        if (data.error) showToast(data.message)
        else {
            Preference.saveToken(data.loginResult.token, requireContext())
            navigateToMainActivity()
        }
    }

    private fun FragmentLoginBinding.setLoadingState(state: Boolean) {
        pbLogin.isVisible = state
        edLoginEmail.isInvisible = state
        edLoginPassword.isInvisible = state
        btLogin.isInvisible = state
        textView6.isInvisible = state
        tvLoginDontHaveAccount.isInvisible = state
    }

    private fun handleBackPressed() {
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                requireActivity().finish()
            }
        })
    }

    private fun navigateToMainActivity() {
        findNavController().navigate(R.id.action_loginFragment_to_mainActivity)
        requireActivity().finish()
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
package com.example.capstonever.utils

import android.content.Context
import android.content.SharedPreferences

object Preference {

    // Initialize SharedPreferences with a given name
    fun initPref(context: Context, name: String): SharedPreferences {
        return context.getSharedPreferences(name, Context.MODE_PRIVATE).also {
            println("Initialized SharedPreferences with name: $name")
        }
    }

    // Get the SharedPreferences.Editor for a given name
    private fun editorPreference(context: Context, name: String): SharedPreferences.Editor {
        return context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().also {
            println("Obtained SharedPreferences.Editor for name: $name")
        }
    }

    // Save a token to SharedPreferences
    fun saveToken(token: String, context: Context) {
        editorPreference(context, "onSignIn").apply {
            putString("token", token)
            println("Saving token: $token")
            apply()
            println("Token saved successfully")
        }
    }

    // Remove token and status from SharedPreferences to log out
    fun logOut(context: Context) {
        editorPreference(context, "onSignIn").apply {
            println("Logging out, removing token and status")
            remove("token")
            remove("status")
            apply()
            println("Logged out successfully")
        }
    }
}

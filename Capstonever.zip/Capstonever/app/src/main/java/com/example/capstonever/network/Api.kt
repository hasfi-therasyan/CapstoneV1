package com.example.capstonever.network

data class SignUpRequest(val username: String, val password: String, val email: String)
data class SignUpResponse(val success: Boolean, val message: String)

data class LoginRequest(val username: String, val password: String)
data class LoginResponse(val token: String)

data class Item(val id: String, val name: String, val description: String, val price: Double, val imageUrl: String)

data class AddItemResponse(val success: Boolean, val message: String)

data class AddToCartRequest(val itemId: String, val quantity: Int)
data class AddToCartResponse(val success: Boolean, val message: String)

data class UpdateItemResponse(val success: Boolean, val message: String)
data class DeleteItemResponse(val success: Boolean, val message: String)

data class CheckoutRequest(val cartItems: List<CartItem>)
data class CheckoutResponse(val success: Boolean, val message: String)

data class UpdateCartRequest(val cartItemId: String, val quantity: Int)
data class UpdateCartResponse(val success: Boolean, val message: String)

data class DeleteCartRequest(val cartItemId: String)
data class DeleteCartResponse(val success: Boolean, val message: String)

data class TrackOrderResponse(val status: String, val estimatedDelivery: String)

data class CartItem(val id: String, val itemId: String, val quantity: Int, val name: String, val price: Double, val imageUrl: String)
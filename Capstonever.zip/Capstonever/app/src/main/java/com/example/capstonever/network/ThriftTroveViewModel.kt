package com.example.capstonever.network

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.example.capstonever.network.LoginRequest
import com.example.capstonever.network.SignUpRequest
import com.example.capstonever.network.ThriftTroveRepository
import kotlinx.coroutines.Dispatchers

class ThriftTroveViewModel(private val repository: ThriftTroveRepository) : ViewModel() {

    fun signUp(request: SignUpRequest) = liveData(Dispatchers.IO) {
        val response = repository.signUp(request)
        emit(response)
    }

    fun login(request: LoginRequest) = liveData(Dispatchers.IO) {
        val response = repository.login(request)
        emit(response)
    }

    fun getItems() = liveData(Dispatchers.IO) {
        val response = repository.getItems()
        emit(response)
    }

    fun getItemById(id: String) = liveData(Dispatchers.IO) {
        val response = repository.getItemById(id)
        emit(response)
    }

    // Add other methods as needed
}
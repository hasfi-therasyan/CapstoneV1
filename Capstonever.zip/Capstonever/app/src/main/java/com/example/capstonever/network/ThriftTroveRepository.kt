package com.example.capstonever.network

import com.example.capstonever.network.AddToCartRequest
import com.example.capstonever.network.CheckoutRequest
import com.example.capstonever.network.DeleteCartRequest
import com.example.capstonever.network.LoginRequest
import com.example.capstonever.network.RetrofitInstance
import com.example.capstonever.network.SignUpRequest
import com.example.capstonever.network.UpdateCartRequest

class ThriftTroveRepository {
    private val api = RetrofitInstance.api

    suspend fun signUp(request: SignUpRequest) = api.signUp(request)
    suspend fun login(request: LoginRequest) = api.login(request)
    suspend fun getItems() = api.getItems()
    suspend fun getItemById(id: String) = api.getItemById(id)
    suspend fun addItem(token: String, image: MultipartBody.Part, name: RequestBody, description: RequestBody, price: RequestBody) = api.addItem(token, image, name, description, price)
    suspend fun addItemToCart(token: String, request: AddToCartRequest) = api.addItemToCart(token, request)
    suspend fun updateItem(token: String, id: String, image: MultipartBody.Part?, name: RequestBody, description: RequestBody, price: RequestBody) = api.updateItem(token, id, image, name, description, price)
    suspend fun deleteItem(token: String, id: String) = api.deleteItem(token, id)
    suspend fun getItemsByOwnerId(token: String) = api.getItemsByOwnerId(token)
    suspend fun checkout(token: String, request: CheckoutRequest) = api.checkout(token, request)
    suspend fun updateCartItem(token: String, request: UpdateCartRequest) = api.updateCartItem(token, request)
    suspend fun getCart(token: String) = api.getCart(token)
    suspend fun deleteCartItem(token: String, request: DeleteCartRequest) = api.deleteCartItem(token, request)
    suspend fun trackOrder(token: String, orderId: String) = api.trackOrder(token, orderId)
}
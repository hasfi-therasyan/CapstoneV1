package com.example.capstonever.login

import androidx.lifecycle.ViewModel
import com.example.storyappdicoding.story.StoryRepository

class LoginViewModel(private val storyRepository: StoryRepository) : ViewModel() {

    fun login(email: String, password: String) = storyRepository.postLogin(email, password)
}
